<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2025-<?php echo date('Y'); ?> <a href="javascript:void(0);">MBOCW-CESS</a>.</strong> All rights reserved.
  </footer>